const express = require("express");
const router = express.Router();
const { login, signup, afterLogin } = require("../controller/loginController");
const validateToken = require("../middleware/validateTokenHandler");
router.post("/login/", login);
router.post("/signup/", signup);
router.post("/afterLogin/", validateToken, afterLogin);
module.exports = router;
