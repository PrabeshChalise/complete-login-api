const jwt = require("jsonwebtoken");
const asyncHandler = require("express-async-handler");
const validateToken = asyncHandler(async (req, res, next) => {
  let token;
  let authHeader = req.headers.authorization || req.headers.Authorization;
  if (authHeader && authHeader.startsWith("Bearer")) {
    token = authHeader.split(" ")[1];
  }
  jwt.verify(token, process.env.ACCESS_TOKEN, (err, decoded) => {
    if (err) {
      res.status(400);
      throw new Error("Error while validation");
    }
    req.user = decoded.user;
    next();
  });
  if (!token) {
    res.status(404);
    throw new Error("Please enter the correct token");
  }
});
module.exports = validateToken;
