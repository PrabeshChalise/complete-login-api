const mongoose = require("mongoose");
const loginSchema = mongoose.Schema({
  username: {
    type: String,
    required: [true, "Please enter username"],
  },
  email: {
    type: String,
    required: [true, "Please enter email"],
    unique: true,
  },
  password: {
    type: String,
    required: [true, "Please enter password"],
  },
  contact: {
    type: Number,
    required: [true, "Please enter contact"],
  },
});
module.exports = mongoose.model("User", loginSchema);
