const asyncHandler = require("express-async-handler");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const User = require("../model/loginModel");

//Controller for signup--------------->>>>>
const signup = asyncHandler(async (req, res) => {
  const { username, email, password, contact } = req.body;
  if (!username || !email || !password || !contact) {
    res.status(404);
    throw new Error("Please enter username, email,  password and contact");
  }
  const hashedPassword = await bcrypt.hash(password, 10);
  console.log(hashedPassword);
  const user = await User.create({
    username,
    email,
    password: hashedPassword,
    contact,
  });
  console.log("User has successfully created");
  if (user) {
    res.status(201).json({
      _id: user.id,
      email: user.email,
    });
  } else {
    res.status(404);
    throw new Error("Error while register");
  }
});

//Controller for login--------------->>>>>
const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    res.status(404);
    throw new Error("Please enter both email and password");
  }
  const user = await User.findOne({ email });
  if (user && (await bcrypt.compare(password, user.password))) {
    const accessToken = jwt.sign(
      {
        user: {
          username: user.username,
          email: user.username,
          contact: user.contact,
          id: user.id,
        },
      },
      process.env.ACCESS_TOKEN,
      { expiresIn: "50m" }
    );
    res.status(200).json({ accessToken });
  } else {
    res.status(400);
    throw new Error("Email or password not valid");
  }
});

//Controller for checking after validation--------------->>>>>
const afterLogin = asyncHandler(async (req, res) => {
  res.send(req.user);
});

module.exports = { login, signup, afterLogin };
