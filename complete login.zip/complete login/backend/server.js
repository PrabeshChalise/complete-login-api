const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv").config();
const dbConnect = require("./database/dbConnect");
dbConnect();
const app = express();
const port = process.env.PORT;
app.use(express.json());
app.use(cors());
app.use("/api/", require("./routes/loginRoutes"));

app.listen(port, (result, err) => {
  if (err) {
    console.log(err);
  }
  console.log(`Server is running in port ${port}`);
});
